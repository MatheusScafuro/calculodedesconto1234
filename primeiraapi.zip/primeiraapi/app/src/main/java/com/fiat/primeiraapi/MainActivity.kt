package com.fiat.primeiraapi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val entrada: EditText = findViewById(R.id.valorEntrada)
        val saida: EditText = findViewById(R.id.valorSaida)
        val calcular: Button = findViewById(R.id.calcular)
        val resetar: Button = findViewById(R.id.resetar)

        calcular.setOnClickListener {
            val string = entrada.text.toString()
            val moeda = string.toInt()
            val i = moeda - 5
            val decimal = i.toString()
            saida.setText(decimal)
        }

        resetar.setOnClickListener {
            entrada.text = null
            saida.text = null
        }
    }
}
